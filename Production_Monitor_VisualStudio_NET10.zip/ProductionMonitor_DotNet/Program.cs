using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddDbContext<ProductionDb>(o => o.UseSqlite("Data Source=production.db"));
builder.Services.ConfigureHttpJsonOptions(o => o.SerializerOptions.Converters.Add(new JsonStringEnumConverter()));
var app = builder.Build();
using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<ProductionDb>();
    db.Database.EnsureCreated();
    if (!db.Records.Any()) Seed(db);
}
app.UseDefaultFiles();
app.UseStaticFiles();

app.MapGet("/api/config", () => new {
    lines = new Dictionary<string, string[]> {
        ["L1"] = new[] { "PRODUCT 1", "PRODUCT 2", "PRODUCT 3", "PRODUCT 4" },
        ["L2"] = new[] { "PRODUCT 2", "PRODUCT 4" },
        ["L3"] = new[] { "PRODUCT 1" },
        ["L4"] = new[] { "PRODUCT 1", "PRODUCT 3", "PRODUCT 5" }
    }, shifts = new[] { "A", "B", "C" }
});
app.MapGet("/api/records", async (ProductionDb db, string? from, string? to, string? line, string? product) => {
    var q = db.Records.AsNoTracking().AsQueryable();
    if (DateOnly.TryParse(from, out var f)) q = q.Where(x => x.Day >= f);
    if (DateOnly.TryParse(to, out var t)) q = q.Where(x => x.Day <= t);
    if (!string.IsNullOrEmpty(line) && line != "all") q = q.Where(x => x.Line == line);
    if (!string.IsNullOrEmpty(product) && product != "all") q = q.Where(x => x.Product == product);
    return await q.OrderByDescending(x => x.Day).ThenBy(x => x.Line).ThenBy(x => x.Shift).ToListAsync();
});
app.MapPost("/api/records", async (ProductionDb db, Entry input) => {
    var allowed = Products(input.Line);
    if (allowed == null || !allowed.Contains(input.Product)) return Results.BadRequest(new { error = "Product is not allowed on this line." });
    if (!new[] { "A", "B", "C" }.Contains(input.Shift)) return Results.BadRequest(new { error = "Invalid shift." });
    if (input.Speed < 0 || input.Production < 0 || input.Energy < 0 || !double.IsFinite(input.Speed) || !double.IsFinite(input.Production) || !double.IsFinite(input.Energy)) return Results.BadRequest(new { error = "Values must be finite and non-negative." });
    if (await db.Records.AnyAsync(x => x.Day == input.Day && x.Line == input.Line && x.Product != input.Product))
        return Results.BadRequest(new { error = "Only one product per line per day is allowed." });
    var record = await db.Records.SingleOrDefaultAsync(x => x.Day == input.Day && x.Line == input.Line && x.Shift == input.Shift);
    if (record == null) {
        record = new ProductionRecord { Day = input.Day, Line = input.Line, Shift = input.Shift };
        db.Records.Add(record);
    }
    record.Product = input.Product;
    record.Speed = input.Speed;
    record.Production = input.Production;
    record.Energy = input.Energy;
    await db.SaveChangesAsync();
    return Results.Ok(record);
});
app.MapGet("/api/dashboard", async (ProductionDb db, string? day, string? line, string? product) => {
    var selected = DateOnly.TryParse(day, out var d) ? d : DateOnly.FromDateTime(DateTime.Today);
    var first = new DateOnly(selected.Year, selected.Month, 1);
    var end = first.AddMonths(1);
    var q = db.Records.AsNoTracking().Where(x => x.Day >= first && x.Day < end);
    if (!string.IsNullOrEmpty(line) && line != "all") q = q.Where(x => x.Line == line);
    if (!string.IsNullOrEmpty(product) && product != "all") q = q.Where(x => x.Product == product);
    var rows = await q.ToListAsync();
    var daily = rows.Where(x => x.Day == selected).ToList();
    return Results.Ok(new {
        day = selected, dailyProduction = daily.Sum(x => x.Production), dailyEnergy = daily.Sum(x => x.Energy),
        monthlyProduction = rows.Sum(x => x.Production), monthlyEnergy = rows.Sum(x => x.Energy),
        dailyByLine = daily.GroupBy(x => x.Line).Select(g => new { label = g.Key, production = g.Sum(x => x.Production), energy = g.Sum(x => x.Energy) }).OrderBy(x => x.label),
        byShift = daily.GroupBy(x => x.Shift).Select(g => new { label = "Shift " + g.Key, production = g.Sum(x => x.Production), energy = g.Sum(x => x.Energy), speed = g.Average(x => x.Speed) }).OrderBy(x => x.label),
        byProduct = rows.GroupBy(x => x.Product).Select(g => new { label = g.Key, production = g.Sum(x => x.Production), energy = g.Sum(x => x.Energy) }).OrderBy(x => x.label),
        trend = rows.GroupBy(x => x.Day).Select(g => new { label = g.Key.ToString("MM-dd"), production = g.Sum(x => x.Production), energy = g.Sum(x => x.Energy), speed = g.Average(x => x.Speed) }).OrderBy(x => x.label)
    });
});
app.Run();

static string[]? Products(string line) => line switch {
    "L1" => new[] { "PRODUCT 1", "PRODUCT 2", "PRODUCT 3", "PRODUCT 4" },
    "L2" => new[] { "PRODUCT 2", "PRODUCT 4" },
    "L3" => new[] { "PRODUCT 1" },
    "L4" => new[] { "PRODUCT 1", "PRODUCT 3", "PRODUCT 5" },
    _ => null
};
static void Seed(ProductionDb db) {
    var rng = new Random(42);
    var lines = new[] { "L1", "L2", "L3", "L4" };
    var today = DateOnly.FromDateTime(DateTime.Today);
    for (int offset = 59; offset >= 0; offset--) {
        var day = today.AddDays(-offset);
        foreach (var line in lines) {
            var products = Products(line)!;
            var product = products[rng.Next(products.Length)];
            foreach (var shift in new[] { "A", "B", "C" }) {
                var speed = Math.Round(65 + rng.NextDouble() * 55, 1);
                db.Records.Add(new ProductionRecord {
                    Day = day, Line = line, Product = product, Shift = shift,
                    Speed = speed, Production = Math.Round(speed * (6.0 + rng.NextDouble()), 1),
                    Energy = Math.Round(80 + rng.NextDouble() * 110, 1)
                });
            }
        }
    }
    db.SaveChanges();
}
public record Entry(DateOnly Day, string Line, string Product, string Shift, double Speed, double Production, double Energy);
public class ProductionRecord {
    public int Id { get; set; }
    public DateOnly Day { get; set; }
    [MaxLength(3)] public string Line { get; set; } = "";
    [MaxLength(30)] public string Product { get; set; } = "";
    [MaxLength(1)] public string Shift { get; set; } = "";
    public double Speed { get; set; }
    public double Production { get; set; }
    public double Energy { get; set; }
}
public class ProductionDb(DbContextOptions<ProductionDb> options) : DbContext(options) {
    public DbSet<ProductionRecord> Records => Set<ProductionRecord>();
    protected override void OnModelCreating(ModelBuilder modelBuilder) {
        modelBuilder.Entity<ProductionRecord>().HasIndex(x => new { x.Day, x.Line, x.Shift }).IsUnique();
    }
}
