# Production Monitor — Visual Studio / .NET 10

## Requirements
- Windows 10/11
- **Visual Studio 2026** with **ASP.NET and web development** workload
- **.NET 10 SDK** installed
- Internet for first NuGet restore and Chart.js CDN

## Open and run
1. Extract the ZIP.
2. Double-click **ProductionMonitor.sln** in the extracted top-level folder.
3. Allow Visual Studio to restore NuGet packages.
4. In Solution Explorer, right-click **ProductionMonitor** project → **Set as Startup Project**.
5. Select the **ProductionMonitor** launch profile (not IIS Express) and press **F5** or **Ctrl+F5**.
6. The browser should open **http://localhost:5050**.

If the browser doesn't open automatically, visit that URL manually once the Output window reports `Now listening on: http://localhost:5050`.

## Alternative terminal run
In `ProductionMonitor_DotNet` folder:
```
dotnet restore
dotnet run --launch-profile ProductionMonitor
```

## Features
- ASP.NET Core 10 minimal APIs + Entity Framework Core 10 + SQLite.
- Operator shift entry, line/product validation, one product per line per day.
- Daily and monthly production and energy KPIs.
- Line/shift/product breakdowns and speed/energy trends.
- Automatically generated 60 days of **sample data** on first run.

## Notes
- SQLite file `production.db` is created automatically on first successful run.
- Sample records are demonstration data, not real factory data.
- Requires internet to load Chart.js charts from CDN.
- This is a demo assignment, not production hardened.
